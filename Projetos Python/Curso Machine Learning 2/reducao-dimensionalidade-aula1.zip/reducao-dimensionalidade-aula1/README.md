# reducao-dimensionalidade
Curso de Redução de dimensionalidade da Alura
